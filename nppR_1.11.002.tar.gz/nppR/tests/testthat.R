library(testthat)
library(nppR)

test_check("nppR")
